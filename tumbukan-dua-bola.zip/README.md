# Simulasi Tumbukan Dua Bola (Momentum & Impuls)

Proyek ini berisi **simulasi interaktif tumbukan dua bola 1D** untuk membantu siswa memahami konsep **momentum dan impuls**.

## 🎯 Tujuan Pembelajaran
- Menjelaskan konsep momentum dan impuls.
- Menyelidiki pengaruh massa dan kecepatan terhadap momentum.
- Menentukan jenis tumbukan berdasarkan koefisien restitusi (e).
- Membuktikan hukum kekekalan momentum pada sistem tertutup.

## 🧩 Fitur Simulasi
- Pengaturan massa dan kecepatan untuk dua bola.
- Pengaturan koefisien restitusi (0–1).
- Visualisasi gerak dan perhitungan momentum secara real-time.
- Mode *Hitung tanpa animasi* untuk analisis cepat.

## 🚀 Cara Menggunakan
1. Buka tautan GitHub Pages berikut:  
   👉 **https://USERNAME.github.io/tumbukan-dua-bola/**
2. Atur nilai massa, kecepatan, dan koefisien restitusi.
3. Tekan **Start** untuk melihat simulasi atau **Hitung tanpa animasi** untuk perhitungan langsung.

## 💡 Dikembangkan oleh
**Salisa “Ndut” Nun Shiha**  
Guru Fisika – Inovasi Pembelajaran Digital  
Didampingi oleh ChatGPT (Glass) ✨

---
*Media ini dikembangkan untuk mendukung pembelajaran berbasis teknologi dan eksplorasi mandiri siswa sesuai Kurikulum Merdeka.*
